package com.example.musicplayer;

public interface SongChangeListener {

    //void onChanged(int position);
    void onChanged(MusicList song);
}
